# website/views.py
from django.shortcuts import render

def home(request):
    """View para a página inicial"""
    context = {
        'titulo': 'Bem-vindo ao Nosso Site',
        'empresa': 'TechSolutions',
        'ano': 2024
    }
    return render(request, 'website/home.html', context)

def sobre(request):
    """View para a página sobre"""
    context = {
        'titulo': 'Sobre Nós',
        'missao': 'Desenvolver soluções tecnológicas inovadoras',
        'visao': 'Ser referência em desenvolvimento web no Brasil',
        'valores': ['Qualidade', 'Inovação', 'Compromisso', 'Transparência']
    }
    return render(request, 'website/sobre.html', context)

def contato(request):
    """View para a página de contato"""
    context = {
        'titulo': 'Entre em Contato',
        'telefone': '(11) 9999-9999',
        'email': 'contato@techsolutions.com.br',
        'endereco': 'Rua das Flores, 123 - São Paulo, SP',
        'horario': 'Segunda a Sexta: 8h às 18h'
    }
    return render(request, 'website/contato.html', context)

def servicos(request):
    """View para a página de serviços"""
    context = {
        'titulo': 'Nossos Serviços',
        'servicos': [
            {
                'nome': 'Desenvolvimento Web',
                'descricao': 'Sites responsivos e modernos com Django e React',
                'preco': 'A partir de R$ 2.500'
            },
            {
                'nome': 'Aplicativos Mobile',
                'descricao': 'Apps nativos para iOS e Android',
                'preco': 'A partir de R$ 5.000'
            },
            {
                'nome': 'Consultoria em TI',
                'descricao': 'Análise e otimização de sistemas existentes',
                'preco': 'R$ 150/hora'
            }
        ]
    }
    return render(request, 'website/servicos.html', context)